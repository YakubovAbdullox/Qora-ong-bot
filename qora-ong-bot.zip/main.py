from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
import os

BOT_TOKEN = os.environ.get("BOT_TOKEN")
ADMIN_CHAT_ID = int(os.environ.get("ADMIN_CHAT_ID"))
CARD_NUMBER = os.environ.get("CARD_NUMBER")
GROUP_LINK = os.environ.get("GROUP_LINK")

ASK_PAYMENT = 1

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "👁 QORA ONG ichkarisiga xush kelibsiz.\n\n"
        "Bu yopiq hudud. Fikrlaringiz himoyasiz.\n\n"
        "💰 Kirish narxi: 1 oy = 5000 so‘m\n"
        "To‘lov uchun Click karta raqami:\n\n"
        f"🔢 {CARD_NUMBER} (Shaxriyor Yakubov)\n\n"
        "❗ To‘lovni amalga oshirgach, iltimos, to‘lov skrinshotini yuboring."
    )
    await update.message.reply_text(text)
    return ASK_PAYMENT

async def receive_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    photo = update.message.photo[-1].file_id if update.message.photo else None

    if photo:
        await context.bot.send_photo(
            chat_id=ADMIN_CHAT_ID,
            photo=photo,
            caption=f"🧾 To'lov skrinshoti\n👤 @{user.username or user.first_name}"
        )
        await update.message.reply_text("✅ To‘lov tasdiqlanishi kutilmoqda. Admin siz bilan tez orada bog‘lanadi.")
    else:
        await update.message.reply_text("⚠️ Iltimos, faqat skrinshot (foto) yuboring.")
    return ASK_PAYMENT

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={ASK_PAYMENT: [MessageHandler(filters.PHOTO, receive_payment)]},
        fallbacks=[]
    )

    app.add_handler(conv_handler)
    app.run_polling()
