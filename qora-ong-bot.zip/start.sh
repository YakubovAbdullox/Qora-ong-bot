#!/bin/bash
pip install -r requirements.txt
python3 main.py
